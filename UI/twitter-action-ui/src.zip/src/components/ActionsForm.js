import React, { useState } from "react";
import { 
  TextField, 
  Checkbox, 
  Button, 
  Stack, 
  FormControlLabel, 
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper
} from "@mui/material";

const ActionsForm = ({ selectedAccounts }) => {
  console.log('selectedAccounts:', selectedAccounts);

  const [tweetUrl, setTweetUrl] = useState("");
  const [like, setLike] = useState(false);
  const [retweet, setRetweet] = useState(false);
  const [comment, setComment] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [results, setResults] = useState(null);

  const handleSubmit = async () => {
    const payload = selectedAccounts.map(account => ({
      accountName: account.name,
      password: account.password,
      tweet_url: tweetUrl,
      like,
      retweet,
      comment,
      comment_text: commentText
    }));

    try {
      const response = await fetch('http://localhost:5000/twitterAction', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      setResults(data.results);
    } catch (error) {
      console.error('İşlem sırasında hata:', error);
      alert('İşlem sırasında bir hata oluştu');
    }
  };

  return (
    <Box sx={{ p: 2, maxWidth: 800, margin: '0 auto' }}>
      <Stack spacing={3}>
        <TextField
          label="Tweet URL"
          fullWidth
          value={tweetUrl}
          onChange={(e) => setTweetUrl(e.target.value)}
        />
        
        <Stack direction="row" spacing={2} justifyContent="center">
          <FormControlLabel
            control={<Checkbox checked={like} onChange={() => setLike(!like)} />}
            label="Like"
          />
          <FormControlLabel
            control={<Checkbox checked={retweet} onChange={() => setRetweet(!retweet)} />}
            label="Retweet"
          />
          <FormControlLabel
            control={<Checkbox checked={comment} onChange={() => setComment(!comment)} />}
            label="Yorum"
          />
        </Stack>

        {comment && (
          <TextField
            label="Yorum"
            fullWidth
            multiline
            rows={3}
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
          />
        )}

        <Button 
          variant="contained" 
          color="primary" 
          onClick={handleSubmit}
          disabled={!selectedAccounts?.length || selectedAccounts.length === 0}
          sx={{ mt: 2 }}
        >
          Çalıştır ({selectedAccounts?.length || 0})
        </Button>

        {results && (
          <TableContainer component={Paper} sx={{ mt: 3 }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Hesap Adı</TableCell>
                  <TableCell>Durum</TableCell>
                  <TableCell>Mesaj</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {results.map((result, index) => (
                  <TableRow key={index}>
                    <TableCell>{result.HesapAdi}</TableCell>
                    <TableCell>{result.Durum}</TableCell>
                    <TableCell>{result.Mesaj}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Stack>
    </Box>
  );
};

export default ActionsForm;
